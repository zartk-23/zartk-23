<div align="center">

<a href="https://github.com/zartk-23">
  <img src="./assets/electric-core.svg" alt="Sarthak Nayak — backend and AI engineer" width="100%" />
</a>

<h1 align="center">Sarthak Nayak</h1>
<p align="center"><strong>Backend and AI-focused developer</strong> · building dependable systems at the edge of AI.</p>

<a href="https://github.com/zartk-23?tab=followers"><img src="https://img.shields.io/github/followers/zartk-23?style=flat-square&label=followers&labelColor=0D1117&color=F7D046" alt="GitHub followers" /></a>
<a href="https://github.com/zartk-23?tab=repositories"><img src="https://img.shields.io/github/stars/zartk-23?style=flat-square&label=stars&labelColor=0D1117&color=F7D046" alt="GitHub stars" /></a>
<a href="https://github.com/zartk-23"><img src="./assets/pokeball-visitor.svg" height="30" alt="Pokéball visitor badge" /></a>
<img src="https://komarev.com/ghpvc/?username=zartk-23&style=for-the-badge&label=POKEDEX%20VISITS&labelColor=0D1117&color=F04B54" alt="Pokédex visits" />

<br />
<br />

[**About**](#about) · [**Selected work**](#selected-work) · [**Stack**](#stack) · [**Stats**](#stats) · [**Thunderbolt**](#thunderbolt-hover) · [**Battle egg**](#battle-egg) · [**Connect**](#connect)

</div>

## About

I am **Sarthak Nayak**, a backend and AI-focused developer who likes systems that are useful, secure, and simple to explain. I am currently building **VectorVault**: tenant-safe semantic search and RAG infrastructure for dependable AI products.

```text
currently building  → VectorVault
interested in       → backend systems · RAG · cloud · system design
engineering style   → less noise · better engineering
```

> Think of this profile as a dark-mode Pokédex entry: curious, experimental, and always training the next evolution.

## Selected work

| Project | What it does | Signals |
| --- | --- | --- |
| [VectorVault](https://github.com/zartk-23/Vector-vault) | Tenant-safe semantic search and RAG infrastructure built around FastAPI, PostgreSQL, Pinecone, Redis, and Docker. | `RAG` `FastAPI` `PostgreSQL` |
| [Redis from scratch](https://github.com/zartk-23/Redis-from-scratch) | A systems-focused implementation project exploring the primitives behind a familiar data-infrastructure tool. | `Python` `Networking` `Systems` |
| [Biomedical Research Assistant](https://github.com/zartk-23/Biomedical-Research-Assistant) | An AI-oriented research project focused on making biomedical information easier to explore and use. | `AI` `Research` `NLP` |
| [RL + XAI fracture-risk reduction](https://github.com/zartk-23/Fracture-Risk-reduction-using-RL-and-XAI) | A research project combining reinforcement learning with explainable AI for risk-reduction workflows. | `RL` `XAI` `Python` |

<details>
<summary><b>More experiments</b></summary>
<br />

| Project | Direction |
| --- | --- |
| [Predicting ASD in children](https://github.com/zartk-23/Predicting-ASD-in-children) | Behavioral-screening-based prediction research |
| [Real-time demand forecasting](https://github.com/zartk-23/Real-Time-Demand-Forecasting-for-FMCG-Products) | Forecasting for FMCG demand planning |
| [XLR8_DRONE](https://github.com/hemnsue/XLR8_DRONE) | Drone and robotics experimentation |

</details>

## Stack

<div align="center">

<a href="https://www.python.org/"><img src="https://img.shields.io/badge/Python-0D1117?style=for-the-badge&logo=python&logoColor=F7D046" alt="Python" /></a>
<a href="https://fastapi.tiangolo.com/"><img src="https://img.shields.io/badge/FastAPI-0D1117?style=for-the-badge&logo=fastapi&logoColor=5BE7FF" alt="FastAPI" /></a>
<a href="https://www.postgresql.org/"><img src="https://img.shields.io/badge/PostgreSQL-0D1117?style=for-the-badge&logo=postgresql&logoColor=5BE7FF" alt="PostgreSQL" /></a>
<a href="https://redis.io/"><img src="https://img.shields.io/badge/Redis-0D1117?style=for-the-badge&logo=redis&logoColor=FF6B6B" alt="Redis" /></a>
<a href="https://www.docker.com/"><img src="https://img.shields.io/badge/Docker-0D1117?style=for-the-badge&logo=docker&logoColor=5BE7FF" alt="Docker" /></a>
<a href="https://www.pinecone.io/"><img src="https://img.shields.io/badge/Pinecone-0D1117?style=for-the-badge&logoColor=F7D046" alt="Pinecone" /></a>
<a href="https://github.com/features/actions"><img src="https://img.shields.io/badge/GitHub_Actions-0D1117?style=for-the-badge&logo=githubactions&logoColor=B99CFF" alt="GitHub Actions" /></a>
<a href="https://git-scm.com/"><img src="https://img.shields.io/badge/Git-0D1117?style=for-the-badge&logo=git&logoColor=F7D046" alt="Git" /></a>

</div>

## Stats

<div align="center">

<a href="https://github.com/zartk-23">
  <img height="170" src="https://github-readme-stats.vercel.app/api?username=zartk-23&custom_title=Trainer%20Stats%20%2F%2F%20Electric%20Type&show_icons=true&include_all_commits=true&hide_border=true&border_radius=16&bg_color=0D1117&border_color=F7D046&title_color=F7D046&text_color=8B949E&icon_color=F7D046&rank_icon=github" alt="Sarthak's Pokémon-themed GitHub stats" />
</a>
<a href="https://github.com/zartk-23">
  <img height="170" src="https://github-readme-stats.vercel.app/api/top-langs/?username=zartk-23&custom_title=Move%20Set%20%2F%2F%20Languages&layout=compact&hide_border=true&border_radius=16&bg_color=0D1117&border_color=5BE7FF&title_color=F7D046&text_color=8B949E&langs_count=8" alt="Top languages in the Pokémon-themed move set card" />
</a>

<br />

<a href="https://github.com/zartk-23">
  <img src="https://streak-stats.demolab.com?user=zartk-23&theme=dark&hide_border=true&background=0D1117&ring=F7D046&fire=F04B54&currStreakLabel=F7D046&sideLabels=8B949E&dates=657185&stroke=F7D046" alt="GitHub contribution streak with electric-type styling" />
</a>

<br />

<a href="https://github.com/zartk-23">
  <img src="https://github-readme-activity-graph.vercel.app/graph?username=zartk-23&bg_color=0D1117&color=8B949E&line=F7D046&point=F04B54&area_color=F7D046&area=true&hide_border=true" alt="Pokémon-themed contribution activity graph" width="96%" />
</a>

</div>

## Particle swarm

<div align="center">

<img src="./assets/particle-swarm.svg" alt="Animated particle swarm forming a Pokéball" width="100%" />

<p><sub>A GitHub-safe particle swarm inspired by the attached Three.js simulator: particles disperse, glow, and reform into a Pokéball.</sub></p>

</div>

## Thunderbolt hover

<details>
<summary><b>Hover the electric companion to trigger Thunderbolt</b></summary>
<br />

<div align="center">

<img src="./assets/pikachu-hover.svg" alt="Hover-triggered thunderbolt animation over an electric companion silhouette" width="100%" />

</div>

> **Interaction note:** the SVG contains a custom CSS `:hover` animation that moves, scales, and flashes the thunderbolt. GitHub may sanitize hover styles inside image previews; the guaranteed full demo is included at [`assets/pikachu-hover.html`](./assets/pikachu-hover.html).

</details>

## Battle egg

<details>
<summary><b>Click to deploy an electric battle</b></summary>
<br />

<div align="center">

<img src="./assets/battle-egg.svg" alt="Animated electric companion battling a violet vector creature" width="100%" />

</div>

> **Battle protocol:** this is a lightweight GitHub Easter egg built from native `<details>` interaction and animated SVG. Click the summary to reveal the arena; no JavaScript, iframe, or external app is required.

</details>

## Current focus

| Focus | What that means in practice |
| --- | --- |
| **Backend systems** | Designing APIs and services that remain understandable as they grow. |
| **RAG infrastructure** | Making retrieval, tenancy, evaluation, and deployment feel less fragile. |
| **Cloud and delivery** | Packaging ideas into reproducible, observable, deployable systems. |
| **System design** | Choosing the smallest architecture that can carry the next version. |

## Connect

If you are building something thoughtful around **AI infrastructure, backend engineering, or applied research**, feel free to open an issue, start a discussion, or reach out through [GitHub](https://github.com/zartk-23).

<div align="center">

<br />

```text
⚡ stay curious · ship clearly · evolve continuously
```

<a href="https://github.com/zartk-23"><img src="https://img.shields.io/badge/enter_the_lab-0D1117?style=for-the-badge&logo=github&logoColor=F7D046&labelColor=0D1117&color=F7D046" alt="Enter the lab" /></a>

</div>

<!--
GitHub-safe design note:
The hero is an animated SVG with SMIL motion and does not depend on JavaScript, CSS, or iframes, which GitHub sanitizes in README content. Commit the assets/ directory alongside this README so the relative hero path resolves correctly.
-->
